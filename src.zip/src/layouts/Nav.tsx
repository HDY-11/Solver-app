// layouts/Nav.tsx — 标签页导航栏
//
// 在 <Routes> 外部，使用 useLocation() 手动解析路径。
// 识别两种路由模式：/app/{renderer}/{content} 和 /app/window/{panel}

import { useLocation } from 'react-router-dom';
import { getRenderer, getPanel } from '../registry/registry';

function Nav() {
  const { pathname } = useLocation();
  const parts = pathname.split('/').filter(Boolean);
  // /app/:renderer/:content  → parts = ['app', renderer, content]
  // /app/window/:panel       → parts = ['app', 'window', panel]
  const renderer = parts.length >= 2 && parts[0] === 'app' ? parts[1] : null;
  const content = parts.length >= 3 && parts[0] === 'app' ? parts[2] : null;
  const rendererDef = renderer ? getRenderer(renderer) : undefined;
  const panelDef = (renderer === 'window' && content) ? getPanel(content) : undefined;

  const label = rendererDef
    ? `${rendererDef.icon} ${decodeURIComponent(content ?? '').split('/').pop()}`
    : panelDef
      ? `📌 ${panelDef.label}`
      : null;

  return (
    <nav className="app-nav">
      {label ? (
        <span className="nav-tab nav-tab--active">{label}</span>
      ) : (
        <span style={{ color: 'var(--gray-500)', fontSize: '0.8125rem' }}>
          无打开的文件
        </span>
      )}
    </nav>
  );
}

export default Nav;