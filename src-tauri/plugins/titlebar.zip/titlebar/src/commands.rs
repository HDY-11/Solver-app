// commands.rs — 前端可调用的 Tauri 命令

use serde::Deserialize;

#[derive(Debug, Clone, Deserialize)]
pub struct TitlebarRegion {
    pub kind: String,
    pub x: i32,
    pub y: i32,
    pub width: i32,
    pub height: i32,
}

/// 更新自定义标题栏区域配置（前端布局变化时调用）
#[tauri::command]
pub fn update_regions(regions: Vec<TitlebarRegion>) {
    #[cfg(target_os = "windows")]
    crate::windows_impl::set_regions(regions);
}

/// 启动全局拖拽追踪（标签拖拽时调用）
#[tauri::command]
pub fn start_drag_track(tab_path: String, tab_label: String) {
    #[cfg(target_os = "windows")]
    crate::windows_impl::start_drag(tab_path, tab_label);
}

/// 停止全局拖拽追踪
#[tauri::command]
pub fn stop_drag_track() {
    #[cfg(target_os = "windows")]
    crate::windows_impl::stop_drag();
}
