// windows_impl.rs — Windows 平台特定实现
//
// 使用 `windows` crate 进行：
// 1. 窗口子类化（WM_NCHITTEST → 自定义区域映射）
// 2. 全局鼠标钩子（WH_MOUSE_LL → 跨窗口拖拽检测）

use std::collections::HashMap;
use std::sync::Mutex;
use std::thread;

use windows::Win32::Foundation::{HWND, LPARAM, LRESULT, WPARAM, POINT};
use windows::Win32::UI::WindowsAndMessaging::{
    CallNextHookEx, CallWindowProcW, DispatchMessageW, GetCursorPos,
    GetMessageW, GetWindowLongPtrW, PostQuitMessage, SetWindowLongPtrW,
    SetWindowsHookExW, TranslateMessage, UnhookWindowsHookEx, WindowFromPoint,
    GWLP_WNDPROC, HTCAPTION, HTCLOSE, HTMAXBUTTON, HTMINBUTTON,
    MSG, WH_MOUSE_LL, WM_LBUTTONUP, WM_NCHITTEST,
};

use crate::commands::TitlebarRegion;

// ── 窗口子类化状态 ─────────────────────────────

static WINDOW_STATES: Mutex<Option<HashMap<isize, WindowState>>> = Mutex::new(None);

struct WindowState {
    original_proc: isize,
    regions: Vec<(i32, i32, i32, i32, String)>,
}

/// 安装窗口子类化
pub unsafe fn install_subclass(hwnd_raw: isize) {
    let mut states = WINDOW_STATES.lock().unwrap();
    if states.is_none() {
        *states = Some(HashMap::new());
    }

    let hwnd = HWND(hwnd_raw as *mut _);
    let original = GetWindowLongPtrW(hwnd, GWLP_WNDPROC);

    states.as_mut().unwrap().insert(
        hwnd_raw,
        WindowState {
            original_proc: original,
            regions: Vec::new(),
        },
    );

    SetWindowLongPtrW(hwnd, GWLP_WNDPROC, subclass_proc_addr());
}

/// 更新区域配置
pub fn set_regions(regions: Vec<TitlebarRegion>) {
    // 区域坐标需要加上窗口装饰偏移（标题栏高度等）
    // 这里假设前端传来的坐标已经是相对于屏幕的像素坐标
    let converted: Vec<_> = regions.into_iter().map(|r| {
        (r.x, r.y, r.width, r.height, r.kind)
    }).collect();

    if let Ok(mut states) = WINDOW_STATES.lock() {
        if let Some(ref mut map) = *states {
            for (_, state) in map.iter_mut() {
                state.regions = converted.clone();
            }
        }
    }
}

/// 获取窗口过程函数地址（转为 isize）
///
/// Rust extern "system" fn 是 C ABI 函数指针，通过中间 raw pointer 提取地址
fn subclass_proc_addr() -> isize {
    let fn_ptr: unsafe extern "system" fn(HWND, u32, WPARAM, LPARAM) -> LRESULT = subclass_proc;
    fn_ptr as *const () as isize
}

/// 自定义窗口过程
unsafe extern "system" fn subclass_proc(
    hwnd: HWND,
    msg: u32,
    wparam: WPARAM,
    lparam: LPARAM,
) -> LRESULT {
    let hwnd_raw = hwnd.0 as isize;

    let (original, regions) = {
        let states = WINDOW_STATES.lock().unwrap();
        match states.as_ref().and_then(|m| m.get(&hwnd_raw)) {
            Some(s) => (s.original_proc, s.regions.clone()),
            None => (0, Vec::new()),
        }
    };

    if msg == WM_NCHITTEST {
        // lparam: LOWORD(x), HIWORD(y) — 屏幕坐标
        let mx = ((lparam.0 as u64) & 0xFFFF) as i32;
        let my = ((lparam.0 as u64) >> 16) as i32;

        for (rx, ry, rw, rh, ref kind) in &regions {
            if mx >= *rx && mx <= *rx + *rw && my >= *ry && my <= *ry + *rh {
                let hit = match kind.as_str() {
                    "caption" => HTCAPTION,
                    "maxbutton" => HTMAXBUTTON,
                    "minbutton" => HTMINBUTTON,
                    "closebutton" => HTCLOSE,
                    _ => HTCAPTION,
                };
                // HTxxx 是 u32 常量，直接转为 isize
                return LRESULT(hit as isize);
            }
        }
    }

    if original != 0 {
        let proc: unsafe extern "system" fn(HWND, u32, WPARAM, LPARAM) -> LRESULT =
            std::mem::transmute(original);
        CallWindowProcW(Some(proc), hwnd, msg, wparam, lparam)
    } else {
        LRESULT(0)
    }
}

// ── 全局鼠标钩子 ─────────────────────────────

static DRAG_ACTIVE: Mutex<bool> = Mutex::new(false);

pub fn start_drag(_path: String, _label: String) {
    let mut active = DRAG_ACTIVE.lock().unwrap();
    if *active { return; }
    *active = true;
    drop(active);

    thread::spawn(|| {
        unsafe { hook_thread() };
    });
}

pub fn stop_drag() {
    *DRAG_ACTIVE.lock().unwrap() = false;
    unsafe { PostQuitMessage(0) };
}

unsafe fn hook_thread() {
    let hook = SetWindowsHookExW(WH_MOUSE_LL, Some(hook_proc), None, 0);
    let Ok(_hook) = hook else { return; };

    let mut msg = MSG::default();
    loop {
        let ret = GetMessageW(&mut msg, None, 0, 0);
        if ret.0 <= 0 { break; }
        let _ = TranslateMessage(&msg);
        let _ = DispatchMessageW(&msg);
    }

    let _ = UnhookWindowsHookEx(_hook);
}

unsafe extern "system" fn hook_proc(
    code: i32,
    w_param: WPARAM,
    l_param: LPARAM,
) -> LRESULT {
    if code >= 0 && w_param.0 == WM_LBUTTONUP as usize {
        let mut pt = POINT::default();
        let _ = GetCursorPos(&mut pt);
        let _under = WindowFromPoint(pt);

        // TODO: 通过 Tauri 事件通知前端合并
        // 需要 AppHandle，可从全局状态获取

        PostQuitMessage(0);
    }
    CallNextHookEx(None, code, w_param, l_param)
}
